using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class Manager : MonoBehaviour
{
    
    public Button btnGo;
    public List<int> displayList;
    public TextMeshProUGUI fizzBuzzDisplay;

    public int maxVal = 0;
   public void NumberGenerate()
    {
        
    }

    public string FizzBuzz(List<int> displayList, TextMeshProUGUI fizzBuzzDisplay)
    {
        foreach (var number in displayList)
        {
            if (number % 3 == 0 && number % 5 == 0)
            {
                fizzBuzzDisplay.text += "FizzBuzz" + ",";

            }
            else if (number % 3 == 0)
            {
                fizzBuzzDisplay.text += "Fizz" + ",";

            }
            else if (number % 5 == 0)
            {
                fizzBuzzDisplay.text += "Buzz" + ",";

            }
            else
            {
                fizzBuzzDisplay.text += number + ";";
            }
            Debug.Log(fizzBuzzDisplay.text);
        }
        return fizzBuzzDisplay.text;

    }
}
